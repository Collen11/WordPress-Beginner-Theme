<h3>ASIDE POST: <?php the_title();?></h3>
<small>Posted on: <?php the_time('F j,Y');?> at <?php the_time('g:i a');?>, in<?php the_category();?></small>
<hr>